package com.lti.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.lti.pojo.Mobile;

public class MobileRowMapper implements RowMapper<Mobile>
{
	@Override
	public Mobile mapRow(ResultSet rs, int rowNum) throws SQLException {
		Mobile m=new Mobile();
		m.setImeno(rs.getInt("imeno"));
		m.setModelName(rs.getString("modelname"));
		m.setManufac(rs.getString("manufac"));
		return m;
	}
	
}
