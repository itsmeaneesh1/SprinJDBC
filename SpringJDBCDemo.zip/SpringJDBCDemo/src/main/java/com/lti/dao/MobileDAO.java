package com.lti.dao;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import com.lti.pojo.Mobile;

public class MobileDAO
{
		private DataSource dataSource;
		private JdbcTemplate jdbcObj;
		
		public void setDataSource(DataSource dataSource) {
			this.dataSource = dataSource;
			this.jdbcObj=new JdbcTemplate(dataSource);
		}
		
		public void addMobile(Mobile mobile)
		{
			String qry="insert into MobileData values(?,?,?)";
			jdbcObj.update(qry, mobile.getImeno(),mobile.getModelName(),mobile.getManufac());
			System.out.println("Mobile Added..");
		}
		
		
}
