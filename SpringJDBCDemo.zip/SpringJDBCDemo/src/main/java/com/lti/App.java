package com.lti;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lti.dao.MobileDAO;
import com.lti.pojo.Mobile;


public class App 
{
    public static void main( String[] args )
    {
    		ApplicationContext context=new ClassPathXmlApplicationContext("mybeans.xml");
    		
    		MobileDAO jdo= (MobileDAO) context.getBean("mydao");
    		
    		Mobile m=new Mobile(7788,"V12", "vivo");
    		
    		jdo.addMobile(m);
    	
			
    }
}
